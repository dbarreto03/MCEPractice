package com.mindtree.main;

public class IceCream {

	private int creamID;
	private String brand;
	private String flavor;
	
	
	
	public IceCream() {
		super();
	}
	
	
	public IceCream(int creamID, String brand, String flavor) {
		super();
		this.creamID = creamID;
		this.brand = brand;
		this.flavor = flavor;
	}


	public int getCreamID() {
		return creamID;
	}
	
	public void setCreamID(int creamID) {
		this.creamID = creamID;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getFlavor() {
		return flavor;
	}
	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}


	@Override
	public String toString() {
		return "IceCream [creamID=" + creamID + ", brand=" + brand
				+ ", flavor=" + flavor + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result + creamID;
		result = prime * result + ((flavor == null) ? 0 : flavor.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IceCream other = (IceCream) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (creamID != other.creamID)
			return false;
		if (flavor == null) {
			if (other.flavor != null)
				return false;
		} else if (!flavor.equals(other.flavor))
			return false;
		return true;
	} 
	
	
}
