package com.mindtree.main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class IceCreamTest {

	public static void main(String[] args) {
		IceCream option1 = new IceCream();
		IceCream option2 = new IceCream();
		IceCream option3 = new IceCream(3,"Cold Stone", "Cake Batter");
		ArrayList<IceCream>iceList = new ArrayList<IceCream>();
		Scanner scanner = new Scanner(System.in);
		Scanner scanner2 = new Scanner(System.in);
		Scanner scanner3 = new Scanner(System.in);
		//Iterator<String> creamIter = iceList.iterator<IceCream>();
		
		System.out.println("What is your favorite ice cream brand?");
		String brand1 = scanner.next();
		//scanner.close();
		System.out.println("What is your favorite flavor?");
		String flavor1 = scanner2.next();
		//scanner2.close();
		System.out.println("What is your second favorite ice cream brand?");
		String brand2 = scanner3.next();
		System.out.println("What is your second favorite flavor?");
		String flavor2 = scanner3.next();
		//scanner3.close();
		
		scanner.close();
		scanner2.close();
		scanner3.close();
		
		option1.setCreamID(1);
		option1.setBrand(brand1);
		option1.setFlavor(flavor1);
		
		option2.setCreamID(2);
		option2.setBrand(brand2);
		option2.setFlavor(flavor2);
		
		iceList.add(option1);
		iceList.add(option2);
		iceList.add(option3);
		
		System.out.println("Here are your favorite flavors and I included mine as well:");
		for (IceCream cream : iceList){
			System.out.println("Brand: " + cream.getBrand());
			System.out.println("Flavor: "+ cream.getFlavor());
		}
		
		
		for (IceCream cream : iceList){
			System.out.println("Brand: " + cream.getBrand());
			System.out.println("Flavor: "+ cream.getFlavor());
		}
	}

}
